# HackerRank-3rdSem-Portfolio

**HackerRank Profile:** https://www.hackerrank.com/profile/YOUR_HACKERRANK_USERNAME
**Student:** YOUR NAME — YOUR STUDENT ID (REVA University, B.Tech CSE, 3rd Semester)

## About this repository

Activity 8 — HackerRank & GitHub Problem-Solving Portfolio. This repository holds five HackerRank problems solved in C++ on arrays, matrices, strings and hash maps. Each problem has its own folder with a commented `solution.cpp` (including local test cases) and a `README.md` with the approach, complexity and notes.

## Accepted submissions

Every problem below was accepted with all test cases passing (screenshots in [`screenshots/`](screenshots/)).

| # | Problem | Difficulty | Folder | Proof |
|---|---------|-----------|--------|-------|
| 1 | [Diagonal Difference](https://www.hackerrank.com/challenges/diagonal-difference/problem) | Easy | [01-Diagonal-Difference](01-Diagonal-Difference/) | [screenshot](screenshots/01-diagonal-difference.jpg) |
| 2 | [Dynamic Array](https://www.hackerrank.com/challenges/dynamic-array/problem) | Easy | [02-Dynamic-Array](02-Dynamic-Array/) | [screenshot](screenshots/02-dynamic-array.jpg) |
| 3 | [Time Conversion](https://www.hackerrank.com/challenges/time-conversion/problem) | Easy | [03-Time-Conversion](03-Time-Conversion/) | [screenshot](screenshots/03-time-conversion.jpg) |
| 4 | [Compare the Triplets](https://www.hackerrank.com/challenges/compare-the-triplets/problem) | Easy | [04-Compare-the-Triplets](04-Compare-the-Triplets/) | [screenshot](screenshots/04-compare-the-triplets.jpg) |
| 5 | [Sparse Arrays](https://www.hackerrank.com/challenges/sparse-arrays/problem) | Medium | [05-Sparse-Arrays](05-Sparse-Arrays/) | [screenshot](screenshots/05-sparse-arrays.jpg) |

## Badge evidence

The Problem Solving badge earned its **1st star** (progress 75/100 toward the 2nd star after the fifth problem). The badge icon is visible in the screenshots above, e.g. [Sparse Arrays](screenshots/05-sparse-arrays.jpg).

## Time and space complexity summary

| Problem | Time | Space |
|---------|------|-------|
| Diagonal Difference | O(N) | O(1) |
| Dynamic Array | O(N + Q) | O(N) |
| Time Conversion | O(1) | O(1) |
| Compare the Triplets | O(1) | O(1) |
| Sparse Arrays | O(N + Q) | O(N) |

Sparse Arrays uses a hash map (O(N + Q)) instead of the brute-force nested loop (O(N × Q)).

## Approach per problem

1. **Diagonal Difference** — One loop over `i = 0..n-1`, adding `arr[i][i]` and `arr[i][n-1-i]` together; return the absolute difference.
2. **Dynamic Array** — Keep `n` sequences and a `lastAnswer`. Each query picks sequence `(x XOR lastAnswer) % n`; type 1 appends `y`, type 2 reads element `y % size` and updates `lastAnswer`.
3. **Time Conversion** — Read the hour and AM/PM. 12AM becomes 00, 12PM stays 12, other PM hours add 12; reattach `:mm:ss`.
4. **Compare the Triplets** — Compare the 3 positions; the larger value scores a point, ties score none.
5. **Sparse Arrays** — Build a frequency hash map of the strings, then answer each query by lookup (0 if absent).

## Repository structure

```
HackerRank-3rdSem-Portfolio/
├── README.md
├── screenshots/
├── 01-Diagonal-Difference/   (solution.cpp, README.md)
├── 02-Dynamic-Array/
├── 03-Time-Conversion/
├── 04-Compare-the-Triplets/
└── 05-Sparse-Arrays/
```

Compile and run any solution: `g++ -std=c++17 solution.cpp -o sol && ./sol`
