## Problem: Compare the Triplets (Easy)

**Link:** https://www.hackerrank.com/challenges/compare-the-triplets/problem

### Approach
Iterated over all 3 positions and compared the corresponding elements of Alice's and Bob's arrays. Incremented Alice's score if her value is greater, Bob's if his is greater, and skipped the position entirely on a tie. Returned both scores as a vector.

### Complexity
- Time: O(1) — exactly 3 comparisons, fixed input size
- Space: O(1) — only two integer counters used

### Notes
The tie case (equal elements) awards no points to either player — a common mistake is to award both a point. The loop runs exactly 3 times regardless of input values, making this truly constant time and space.
