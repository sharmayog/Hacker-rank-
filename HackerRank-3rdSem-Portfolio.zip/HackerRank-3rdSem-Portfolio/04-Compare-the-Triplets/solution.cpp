#include <iostream>
#include <vector>
using namespace std;

// ─── Solution ───────────────────────────────────────────────────────────────
// Compare each element; award 1 point to whoever is greater at that position
vector<int> compareTriplets(vector<int>& a, vector<int>& b) {
    int aliceScore = 0, bobScore = 0;
    for (int i = 0; i < 3; i++) {
        if (a[i] > b[i])      aliceScore++;
        else if (a[i] < b[i]) bobScore++;
        // equal → no point awarded
    }
    return {aliceScore, bobScore};
}

// ─── Test Cases ─────────────────────────────────────────────────────────────
int main() {
    // Test 1 — Typical case
    // a = [5, 6, 7], b = [3, 6, 10]
    // Position 0: 5 > 3 → Alice +1
    // Position 1: 6 = 6 → no point
    // Position 2: 7 < 10 → Bob +1
    // Expected output: 1 1
    vector<int> a1 = {5, 6, 7}, b1 = {3, 6, 10};
    auto r1 = compareTriplets(a1, b1);
    cout << "Test 1 (expected 1 1): " << r1[0] << " " << r1[1] << endl;

    // Test 2 — Mixed case: Alice wins 2, Bob wins 1
    // a = [17, 28, 30], b = [99, 16, 8]
    // Position 0: 17 < 99 → Bob +1
    // Position 1: 28 > 16 → Alice +1
    // Position 2: 30 > 8  → Alice +1
    // Expected output: 2 1
    vector<int> a2 = {17, 28, 30}, b2 = {99, 16, 8};
    auto r2 = compareTriplets(a2, b2);
    cout << "Test 2 (expected 2 1): " << r2[0] << " " << r2[1] << endl;

    return 0;
}
