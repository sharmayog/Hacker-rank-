## Problem: Dynamic Array (Easy)

**Link:** https://www.hackerrank.com/challenges/dynamic-array/problem

### Approach
Maintained a 2D vector `seqList` of n empty sequences and a `lastAnswer` variable initialized to 0. For each query, the target sequence index is computed using XOR with `lastAnswer` modulo n. Query type 1 appends a value; query type 2 uses the modulo of y against the current sequence size to retrieve a value, updates `lastAnswer`, and records it in the result.

### Complexity
- Time: O(N + Q) — N to initialize seqList, Q to process each query
- Space: O(N) — seqList grows proportionally to the number of type-1 queries

### Notes
The XOR with `lastAnswer` is what makes the index dynamic — it changes based on previous type-2 results. The modulo `y % seqList[idx].size()` ensures the index wraps around valid bounds, but this assumes at least one type-1 query has been made for that index before any type-2 query targets it (guaranteed by HackerRank constraints).
