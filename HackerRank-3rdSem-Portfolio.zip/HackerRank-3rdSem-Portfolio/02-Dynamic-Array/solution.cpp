#include <iostream>
#include <vector>
using namespace std;

// ─── Solution ───────────────────────────────────────────────────────────────
// Query type 1: idx = (x XOR lastAnswer) % n → append y to seqList[idx]
// Query type 2: idx = (x XOR lastAnswer) % n → lastAnswer = seqList[idx][y % size]
//               print lastAnswer

vector<int> dynamicArray(int n, vector<vector<int>>& queries) {
    vector<vector<int>> seqList(n);
    vector<int> results;
    int lastAnswer = 0;

    for (auto& q : queries) {
        int type = q[0], x = q[1], y = q[2];
        int idx = (x ^ lastAnswer) % n;

        if (type == 1) {
            seqList[idx].push_back(y);
        } else { // type == 2
            lastAnswer = seqList[idx][y % seqList[idx].size()];
            results.push_back(lastAnswer);
        }
    }
    return results;
}

// ─── Test Cases ─────────────────────────────────────────────────────────────
int main() {
    // Test 1 — Typical case (HackerRank sample)
    // n = 2, queries:
    //   1 0 5  -> idx = (0^0)%2 = 0 -> seqList[0] = [5]
    //   1 1 7  -> idx = (1^0)%2 = 1 -> seqList[1] = [7]
    //   1 0 3  -> idx = (0^0)%2 = 0 -> seqList[0] = [5,3]
    //   2 1 0  -> idx = (1^0)%2 = 1 -> lastAnswer = seqList[1][0%1] = 7 -> print 7
    //   2 1 1  -> idx = (1^7)%2 = 0 -> lastAnswer = seqList[0][1%2] = 3 -> print 3
    // Expected output: 7 3
    int n1 = 2;
    vector<vector<int>> q1 = {{1,0,5},{1,1,7},{1,0,3},{2,1,0},{2,1,1}};
    vector<int> res1 = dynamicArray(n1, q1);
    cout << "Test 1 (expected 7 3): ";
    for (int v : res1) cout << v << " ";
    cout << endl;

    // Test 2 — Edge case: single sequence, single query type 2
    // n = 1 → all appends go to seqList[0]
    //   1 0 3  → idx = (0^0)%1 = 0 → seqList[0] = [3]
    //   2 0 0  → idx = (0^0)%1 = 0 → lastAnswer = seqList[0][0] = 3 → print 3
    // Expected output: 3
    int n2 = 1;
    vector<vector<int>> q2 = {{1,0,3},{2,0,0}};
    vector<int> res2 = dynamicArray(n2, q2);
    cout << "Test 2 (expected 3):   ";
    for (int v : res2) cout << v << " ";
    cout << endl;

    return 0;
}
