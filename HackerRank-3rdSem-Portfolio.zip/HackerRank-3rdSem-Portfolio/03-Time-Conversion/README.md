## Problem: Time Conversion (Easy)

**Link:** https://www.hackerrank.com/challenges/time-conversion/problem

### Approach
Extracted the period (AM/PM) and the hour from the input string using `substr`. Applied the two special cases — 12AM becomes 00 and 12PM stays 12 — then handled all remaining AM hours (unchanged) and PM hours (+12). Reconstructed the output string by padding the hour to two digits and appending the unchanged minutes and seconds.

### Complexity
- Time: O(1) — fixed-length string, no loops
- Space: O(1) — only a few string variables used

### Notes
The two trickiest edge cases are 12:xx:xxAM (midnight → 00) and 12:xx:xxPM (noon → stays 12). Missing either one causes wrong output on those specific HackerRank test cases. Always test both before submitting.
