#include <iostream>
#include <string>
using namespace std;

// ─── Solution ───────────────────────────────────────────────────────────────
// Format: "hh:mm:ssAM" or "hh:mm:ssPM"  →  "HH:mm:ss" (24-hour)
// Rules:
//   12:xx:xxAM → 00:xx:xx  (midnight hour)
//   12:xx:xxPM → 12:xx:xx  (noon hour, unchanged)
//   hh:xx:xxAM → hh:xx:xx  (morning, unchanged)
//   hh:xx:xxPM → (hh+12):xx:xx

string timeConversion(string s) {
    string period = s.substr(8, 2); // "AM" or "PM"
    int hour = stoi(s.substr(0, 2));

    if (period == "AM") {
        if (hour == 12) hour = 0;   // 12AM → midnight (00)
    } else {
        if (hour != 12) hour += 12; // PM hours except 12PM
    }

    // Format hour back to two digits
    string result = (hour < 10 ? "0" : "") + to_string(hour);
    result += s.substr(2, 6); // append :mm:ss
    return result;
}

// ─── Test Cases ─────────────────────────────────────────────────────────────
int main() {
    // Test 1 — Typical case: PM time
    // Input:  "07:05:45PM"
    // Expected output: "19:05:45"
    cout << "Test 1 (expected 19:05:45): " << timeConversion("07:05:45PM") << endl;

    // Test 2 — Edge case: 12:00:00AM (midnight)
    // Input:  "12:00:00AM"
    // Expected output: "00:00:00"
    cout << "Test 2 (expected 00:00:00): " << timeConversion("12:00:00AM") << endl;

    // Test 3 — Edge case: 12:00:00PM (noon)
    // Input:  "12:00:00PM"
    // Expected output: "12:00:00"
    cout << "Test 3 (expected 12:00:00): " << timeConversion("12:00:00PM") << endl;

    return 0;
}
