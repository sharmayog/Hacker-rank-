#include <iostream>
#include <vector>
#include <string>
#include <unordered_map>
using namespace std;

// ─── Solution ───────────────────────────────────────────────────────────────
// For each query string, count how many times it appears in the strings array
vector<int> matchingStrings(vector<string>& strings, vector<string>& queries) {
    unordered_map<string, int> freq;
    for (const string& s : strings)
        freq[s]++;

    vector<int> results;
    for (const string& q : queries)
        results.push_back(freq.count(q) ? freq[q] : 0);

    return results;
}

// ─── Test Cases ─────────────────────────────────────────────────────────────
int main() {
    // Test 1 — Typical case
    // strings = ["ab","ab","abc"], queries = ["ab","abc","bc"]
    // "ab"  appears 2 times
    // "abc" appears 1 time
    // "bc"  appears 0 times
    // Expected output: 2 1 0
    vector<string> s1 = {"ab", "ab", "abc"};
    vector<string> q1 = {"ab", "abc", "bc"};
    auto r1 = matchingStrings(s1, q1);
    cout << "Test 1 (expected 2 1 0): ";
    for (int v : r1) cout << v << " ";
    cout << endl;

    // Test 2 — Edge case: query string not present at all
    // strings = ["hello","world"], queries = ["foo","hello"]
    // "foo"   appears 0 times
    // "hello" appears 1 time
    // Expected output: 0 1
    vector<string> s2 = {"hello", "world"};
    vector<string> q2 = {"foo", "hello"};
    auto r2 = matchingStrings(s2, q2);
    cout << "Test 2 (expected 0 1):   ";
    for (int v : r2) cout << v << " ";
    cout << endl;

    return 0;
}
