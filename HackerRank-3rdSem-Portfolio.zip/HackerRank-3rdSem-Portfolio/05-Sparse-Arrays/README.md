## Problem: Sparse Arrays (Medium)

**Link:** https://www.hackerrank.com/challenges/sparse-arrays/problem

### Approach
Built a frequency hash map from the strings array in a single pass — each string maps to its occurrence count. Then for each query, looked up the count directly in the map (O(1) average), returning 0 if the query string was never seen. This avoids the O(N×Q) brute-force nested loop approach.

### Complexity
- Time: O(N + Q) — one pass to build the map, one pass through queries
- Space: O(N) — hash map stores at most N unique strings

### Notes
Using `freq.count(q)` before accessing `freq[q]` avoids accidentally inserting a zero entry for every missing query string, which would bloat memory. An alternative is `freq[q]` directly since uninitialized map values default to 0 in C++, but explicit checking is cleaner and safer.
