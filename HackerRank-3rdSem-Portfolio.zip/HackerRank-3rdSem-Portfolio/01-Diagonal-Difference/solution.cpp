#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

// ─── Solution ───────────────────────────────────────────────────────────────
int diagonalDifference(vector<vector<int>>& arr) {
    int n = arr.size();
    int primarySum = 0, secondarySum = 0;
    for (int i = 0; i < n; i++) {
        primarySum   += arr[i][i];         // top-left to bottom-right
        secondarySum += arr[i][n - 1 - i]; // top-right to bottom-left
    }
    return abs(primarySum - secondarySum);
}

// ─── Test Cases ─────────────────────────────────────────────────────────────
int main() {
    // Test 1 — Typical case: 3x3 matrix
    // Primary diagonal:   11 + 5 + -12 = 4
    // Secondary diagonal:  4 + 5 +  10 = 19
    // Expected output: |4 - 19| = 15
    vector<vector<int>> matrix1 = {
        {11,  2,  4},
        { 4,  5,  6},
        {10,  8, -12}
    };
    cout << "Test 1 (expected 15): " << diagonalDifference(matrix1) << endl;

    // Test 2 — Edge case: 1x1 matrix
    // Primary = Secondary = same element → difference = 0
    vector<vector<int>> matrix2 = {{7}};
    cout << "Test 2 (expected 0):  " << diagonalDifference(matrix2) << endl;

    return 0;
}
