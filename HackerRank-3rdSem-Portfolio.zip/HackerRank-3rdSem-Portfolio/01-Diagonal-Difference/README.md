## Problem: Diagonal Difference (Easy)

**Link:** https://www.hackerrank.com/challenges/diagonal-difference/problem

### Approach
Traversed the matrix once using a single loop from index 0 to n-1. At each step, accumulated the primary diagonal element `arr[i][i]` and the secondary diagonal element `arr[i][n-1-i]` simultaneously. Returned the absolute difference of both sums at the end — no need for a separate pass.

### Complexity
- Time: O(N) — single pass through n rows
- Space: O(1) — only two integer accumulators used

### Notes
Edge case: a 1×1 matrix has both diagonals pointing to the same element, so the difference is always 0. The formula handles this automatically. Negative matrix values are valid — `abs()` from `<cmath>` ensures the result is always non-negative.
